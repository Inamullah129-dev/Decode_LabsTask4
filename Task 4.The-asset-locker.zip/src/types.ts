export interface User {
  id: number;
  email: string;
  full_name: string;
  role: 'borrower' | 'admin';
}

export interface Asset {
  id: number;
  name: string;
  description: string;
  category: string;
  location: string;
  total_quantity: number;
  available_quantity: number;
  image_url: string;
  created_at: string;
  updated_at: string;
}

export interface Loan {
  id: number;
  asset_id: number;
  borrower_id: number;
  borrowed_at: string;
  due_date: string;
  returned_at: string | null;
  status: 'active' | 'returned' | 'overdue';
  asset: Asset;
  borrower: User;
  _idempotent_note?: string;
}

export interface InventoryStats {
  totalAssets: number;
  totalUnits: number;
  availableUnits: number;
  borrowedUnits: number;
  activeLoans: number;
  overdueLoans: number;
  lowStockCount: number;
}
