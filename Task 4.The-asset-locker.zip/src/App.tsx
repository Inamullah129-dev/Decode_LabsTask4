import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Sidebar, NavTab } from './components/Sidebar.tsx';
import { Navbar } from './components/Navbar.tsx';
import { AssetCard } from './components/AssetCard.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { AssetDetailModal } from './components/AssetDetailModal.tsx';
import { ManageAssetModal } from './components/ManageAssetModal.tsx';
import { AiConciergeModal } from './components/AiConciergeModal.tsx';
import { ToastContainer, ToastMessage } from './components/ToastContainer.tsx';
import { getStoredUser, clearAuthSession, apiRequest } from './lib/api.ts';
import { Asset, Loan, InventoryStats, User } from './types.ts';
import { 
  Package, LayoutDashboard, Clock, History, Settings, Sparkles, 
  Plus, Edit, Trash2, CheckCircle2, AlertCircle, ArrowRight, ShieldAlert,
  RefreshCw, Filter, Layers, BarChart3
} from 'lucide-react';

export default function App() {
  // Navigation & View State
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [currentUser, setCurrentUser] = useState<User | null>(getStoredUser);

  // Data State
  const [assets, setAssets] = useState<Asset[]>([]);
  const [categories, setCategories] = useState<string[]>(['All']);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [stats, setStats] = useState<InventoryStats>({
    totalAssets: 0,
    totalUnits: 0,
    availableUnits: 0,
    borrowedUnits: 0,
    activeLoans: 0,
    overdueLoans: 0,
    lowStockCount: 0
  });
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [reportLoading, setReportLoading] = useState(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState<'All' | 'available' | 'borrowed'>('All');

  // Modals & Feedback
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [detailModalAsset, setDetailModalAsset] = useState<Asset | null>(null);
  const [manageModalAsset, setManageModalAsset] = useState<{ isOpen: boolean; asset: Asset | null }>({ isOpen: false, asset: null });
  const [aiConciergeOpen, setAiConciergeOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [borrowingIds, setBorrowingIds] = useState<Record<number, boolean>>({});

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts((prev) => [...prev, { id, type, message }]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // PRD Section 2 & 4.1: Polling mechanism to solve the "Frozen Webpage Problem"
  const loadData = useCallback(async (quiet = false) => {
    try {
      // Fetch Assets with query parameters (PRD GET /api/assets?q=...)
      const queryParams = new URLSearchParams();
      if (searchQuery.trim()) queryParams.set('q', searchQuery.trim());
      if (selectedCategory !== 'All') queryParams.set('category', selectedCategory);
      if (selectedStatus !== 'All') queryParams.set('status', selectedStatus);

      const [assetsData, catsData, statsData] = await Promise.all([
        apiRequest<Asset[]>(`/api/assets?${queryParams.toString()}`),
        apiRequest<string[]>('/api/assets/categories'),
        apiRequest<InventoryStats>('/api/stats')
      ]);

      setAssets(assetsData);
      setCategories(catsData);
      setStats(statsData);

      // If user logged in, fetch relevant loans
      if (currentUser) {
        const loansEndpoint = currentUser.role === 'admin' ? '/api/loans?all=true' : '/api/loans';
        const loansData = await apiRequest<Loan[]>(loansEndpoint).catch(() => []);
        setLoans(loansData);
      }
    } catch (err: any) {
      if (!quiet) {
        console.error('Data Sync Error:', err);
      }
    }
  }, [searchQuery, selectedCategory, selectedStatus, currentUser]);

  // Initial load & Polling Interval (every 4 seconds)
  useEffect(() => {
    loadData();
    const interval = setInterval(() => {
      loadData(true);
    }, 4000);
    return () => clearInterval(interval);
  }, [loadData]);

  // Trigger AI Report when entering insights tab
  useEffect(() => {
    if (activeTab === 'admin_insights' && currentUser?.role === 'admin') {
      setReportLoading(true);
      apiRequest<{ report: string }>('/api/ai/insights')
        .then((res) => setAiReport(res.report))
        .catch((e) => setAiReport(`Error loading insights: ${e.message}`))
        .finally(() => setReportLoading(false));
    }
  }, [activeTab, currentUser]);

  // ==========================================
  // BORROWING & RETURN WORKFLOWS (PRD Module B)
  // ==========================================

  const handleBorrow = async (asset: Asset, customDueDate?: string) => {
    if (!currentUser) {
      showToast('Please sign in to borrow equipment from the Locker.', 'info');
      setAuthModalOpen(true);
      return;
    }

    // PRD Section 4.2: Optimistic UI & Idempotent Guard
    if (borrowingIds[asset.id]) return;

    setBorrowingIds((prev) => ({ ...prev, [asset.id]: true }));
    const due = customDueDate || new Date(Date.now() + 86400000 * 7).toISOString();

    try {
      await apiRequest('/api/loans', {
        method: 'POST',
        body: JSON.stringify({ asset_id: asset.id, due_date: due })
      });

      showToast(`Success! ${asset.name} checked out. Due date logged.`, 'success');
      setDetailModalAsset(null);
      await loadData();
    } catch (err: any) {
      showToast(`Borrowing failed: ${err.message}`, 'error');
    } finally {
      setBorrowingIds((prev) => ({ ...prev, [asset.id]: false }));
    }
  };

  const handleReturn = async (loanId: number, assetName: string) => {
    try {
      const res = await apiRequest(`/api/loans/${loanId}/return`, {
        method: 'PUT'
      });
      showToast(`Returned ${assetName}. (${res._idempotent_note || 'Stock updated'})`, 'success');
      await loadData();
    } catch (err: any) {
      showToast(`Return Error: ${err.message}`, 'error');
    }
  };

  // ==========================================
  // ADMIN CRUD WORKFLOWS (PRD Module C)
  // ==========================================

  const handleSaveAsset = async (assetData: Partial<Asset>) => {
    try {
      if (manageModalAsset.asset) {
        // PUT Update
        await apiRequest(`/api/assets/${manageModalAsset.asset.id}`, {
          method: 'PUT',
          body: JSON.stringify(assetData)
        });
        showToast(`Updated record for ${assetData.name}`, 'success');
      } else {
        // POST Create
        await apiRequest('/api/assets', {
          method: 'POST',
          body: JSON.stringify(assetData)
        });
        showToast(`Provisioned new inventory item: ${assetData.name}`, 'success');
      }
      await loadData();
    } catch (err: any) {
      throw err;
    }
  };

  const handleDeleteAsset = async (id: number, name: string) => {
    if (!window.confirm(`Are you sure you want to delete "${name}" from inventory?`)) return;

    try {
      await apiRequest(`/api/assets/${id}`, { method: 'DELETE' });
      showToast(`Deleted ${name} from catalog.`, 'success');
      await loadData();
    } catch (err: any) {
      // Demonstrates PRD Section 6.3 Gatekeeper ON DELETE RESTRICT catch
      showToast(`RESTRICT_CONSTRAINT_FAIL: Cannot delete item with active borrower loans attached.`, 'error');
    }
  };

  const handleLogout = () => {
    clearAuthSession();
    setCurrentUser(null);
    setLoans([]);
    setActiveTab('dashboard');
    showToast('Signed out of session.', 'info');
  };

  // ==========================================
  // VIEW RENDERERS MATCHING SLEEK INTERFACE
  // ==========================================

  const renderTopStatGrid = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-white p-5 rounded-2xl border border-[#E8E6E1] shadow-xs hover:border-[#5B7FAA]/40 transition-all">
        <p className="text-gray-500 text-[11px] font-bold uppercase tracking-wider mb-1">Total Assets</p>
        <p className="text-2xl font-bold text-[#2C2C2C]">{stats.totalAssets} Cataloged</p>
        <span className="text-[10px] text-gray-400 font-semibold">{stats.totalUnits} Total Unit Stock</span>
      </div>
      <div className="bg-white p-5 rounded-2xl border border-[#E8E6E1] shadow-xs hover:border-[#5B7FAA]/40 transition-all">
        <p className="text-gray-500 text-[11px] font-bold uppercase tracking-wider mb-1">Currently Lent</p>
        <p className="text-2xl font-bold text-[#5B7FAA]">{stats.borrowedUnits} Borrowed</p>
        <span className="text-[10px] text-[#5B7FAA]/80 font-semibold">{stats.activeLoans} Active Loan Files</span>
      </div>
      <div className="bg-white p-5 rounded-2xl border border-[#E8E6E1] shadow-xs hover:border-[#5B7FAA]/40 transition-all">
        <p className="text-gray-500 text-[11px] font-bold uppercase tracking-wider mb-1">Available Now</p>
        <p className="text-2xl font-bold text-[#D4A373]">{stats.availableUnits} Units</p>
        <span className="text-[10px] text-[#5A7D6B] font-semibold">Ready for Instant Checkout</span>
      </div>
      <div className="bg-white p-5 rounded-2xl border border-[#E8E6E1] shadow-xs hover:border-[#5B7FAA]/40 transition-all">
        <p className="text-gray-500 text-[11px] font-bold uppercase tracking-wider mb-1">Service Needed / Low</p>
        <p className="text-2xl font-bold text-[#B5655B]">{stats.lowStockCount} Items 0 Stock</p>
        <span className="text-[10px] text-[#B5655B] font-semibold">{stats.overdueLoans} Overdue Alerts</span>
      </div>
    </div>
  );

  const renderFilterPills = () => (
    <div className="bg-white p-4 rounded-2xl border border-[#E8E6E1] shadow-xs flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider mr-1 flex items-center gap-1 shrink-0">
          <Filter className="w-3 h-3" /> Category:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              selectedCategory === cat
                ? 'bg-[#2C2C2C] text-white shadow-xs'
                : 'bg-[#F2F0EA] text-[#2C2C2C] hover:bg-[#E8E6E1]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider mr-1">Status:</span>
        {(['All', 'available', 'borrowed'] as const).map((st) => (
          <button
            key={st}
            onClick={() => setSelectedStatus(st)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
              selectedStatus === st
                ? 'bg-[#5B7FAA] text-white shadow-xs'
                : 'bg-[#F2F0EA] text-[#2C2C2C] hover:bg-[#E8E6E1]'
            }`}
          >
            {st}
          </button>
        ))}
      </div>
    </div>
  );

  const renderAssetGrid = (items: Asset[], limit?: number) => {
    const displayItems = limit ? items.slice(0, limit) : items;
    if (displayItems.length === 0) {
      return (
        <div className="bg-white rounded-3xl border border-[#E8E6E1] p-12 text-center text-gray-400">
          <Package className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p className="font-bold text-sm text-[#2C2C2C]">No matching equipment found</p>
          <p className="text-xs mt-1">Try adjusting your search query or category filter pills.</p>
        </div>
      );
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {displayItems.map((asset) => (
          <AssetCard
            key={asset.id}
            asset={asset}
            onBorrow={handleBorrow}
            onSelect={(a) => setDetailModalAsset(a)}
            isBorrowing={!!borrowingIds[asset.id]}
          />
        ))}
      </div>
    );
  };

  const renderLoansTable = (loansList: Loan[], title: string, subtitle: string) => (
    <div className="bg-white rounded-3xl border border-[#E8E6E1] overflow-hidden shadow-xs flex flex-col">
      <div className="px-6 py-4 border-b border-[#E8E6E1] flex justify-between items-center bg-gray-50/80">
        <h2 className="text-sm font-bold text-[#2C2C2C] flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#5B7FAA]" /> {title}
        </h2>
        <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{subtitle}</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-white text-gray-400 font-bold uppercase tracking-wider border-b border-[#E8E6E1]">
            <tr>
              <th className="px-6 py-3">Equipment Item</th>
              <th className="px-6 py-3">Borrower User</th>
              <th className="px-6 py-3">Checked Out</th>
              <th className="px-6 py-3">Due Target</th>
              <th className="px-6 py-3">State</th>
              <th className="px-6 py-3 text-right">Idempotent Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 font-medium">
            {loansList.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                  No borrowing records found in the system.
                </td>
              </tr>
            ) : (
              loansList.map((loan) => {
                const isOverdue = loan.status === 'overdue' || (loan.status === 'active' && new Date(loan.due_date) < new Date());
                const isReturned = loan.status === 'returned';

                return (
                  <tr key={loan.id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="px-6 py-4 font-bold text-[#2C2C2C] flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-[#F2F0EA] flex items-center justify-center font-bold text-[10px] text-[#5B7FAA]">
                        #{loan.asset_id}
                      </div>
                      <span>{loan.asset?.name || 'Unknown Item'}</span>
                    </td>
                    <td className="px-6 py-4 text-gray-600 font-semibold">{loan.borrower?.full_name || 'Staff'}</td>
                    <td className="px-6 py-4 text-gray-500">{new Date(loan.borrowed_at).toLocaleDateString()}</td>
                    <td className={`px-6 py-4 font-bold ${isOverdue && !isReturned ? 'text-[#B5655B]' : 'text-gray-600'}`}>
                      {new Date(loan.due_date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      {isReturned ? (
                        <span className="px-2 py-0.5 bg-[#5A7D6B] text-white rounded text-[10px] font-bold uppercase tracking-wider">
                          RETURNED
                        </span>
                      ) : isOverdue ? (
                        <span className="px-2 py-0.5 bg-[#B5655B] text-white rounded text-[10px] font-bold uppercase tracking-wider animate-pulse">
                          OVERDUE
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-[#5B7FAA] text-white rounded text-[10px] font-bold uppercase tracking-wider">
                          ACTIVE
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      {!isReturned && (
                        <button
                          onClick={() => handleReturn(loan.id, loan.asset?.name || 'Item')}
                          className="text-xs font-bold text-[#5B7FAA] hover:text-[#5B7FAA]/80 py-1 px-3 rounded-lg bg-[#5B7FAA]/10 hover:bg-[#5B7FAA]/20 transition-all cursor-pointer"
                        >
                          Return 1-Click
                        </button>
                      )}
                      {isReturned && <span className="text-gray-400 text-[10px] font-bold">Idempotent 200 OK</span>}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full overflow-hidden font-sans text-[#2C2C2C] bg-[#F2F0EA]">
      {/* Toast Overlay */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(usr) => {
          setCurrentUser(usr);
          showToast(`Authenticated as ${usr.full_name}`, 'success');
          loadData();
        }}
      />

      {/* Asset Detail Modal */}
      <AssetDetailModal
        asset={detailModalAsset}
        isOpen={!!detailModalAsset}
        onClose={() => setDetailModalAsset(null)}
        onBorrow={(a, due) => handleBorrow(a, due)}
        isBorrowing={!!detailModalAsset && !!borrowingIds[detailModalAsset.id]}
      />

      {/* Manage Asset Modal (Admin Gatekeeper) */}
      <ManageAssetModal
        isOpen={manageModalAsset.isOpen}
        editingAsset={manageModalAsset.asset}
        onClose={() => setManageModalAsset({ isOpen: false, asset: null })}
        onSave={handleSaveAsset}
      />

      {/* AI Concierge Modal */}
      <AiConciergeModal isOpen={aiConciergeOpen} onClose={() => setAiConciergeOpen(false)} />

      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'admin_assets' || tab === 'admin_insights') {
            if (currentUser?.role !== 'admin') {
              showToast('Admin Gatekeeper 403: Admin privileges required to enter management portal.', 'error');
            }
          }
        }}
        currentUser={currentUser}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-[#F2F0EA]">
        <Navbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          overdueCount={stats.overdueLoans}
          currentUser={currentUser}
          onOpenAuth={() => setAuthModalOpen(true)}
          onLogout={handleLogout}
          onOpenAi={() => setAiConciergeOpen(true)}
          onNewRequest={() => {
            if (currentUser?.role === 'admin') {
              setManageModalAsset({ isOpen: true, asset: null });
            } else {
              setActiveTab('catalog');
              showToast('Select any available item below to request borrowing.', 'info');
            }
          }}
        />

        <div className="p-8 flex-1 overflow-y-auto space-y-8">
          {/* Top Overview Cards (Sleek Theme) */}
          {renderTopStatGrid()}

          {/* VIEW: DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-[#2C2C2C]">Featured Available Assets</h2>
                  <button
                    onClick={() => setActiveTab('catalog')}
                    className="text-sm text-[#5B7FAA] font-bold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <span>View Full Catalog ({assets.length})</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                {renderAssetGrid(assets.filter((a) => a.available_quantity > 0), 3)}
              </div>

              {/* My active loans snippet */}
              {currentUser &&
                renderLoansTable(
                  loans.filter((l) => l.status !== 'returned').slice(0, 4),
                  'My Active & Overdue Borrowings',
                  `Showing ${loans.filter((l) => l.status !== 'returned').length} Active`
                )}
            </div>
          )}

          {/* VIEW: ASSET CATALOG */}
          {activeTab === 'catalog' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-[#2C2C2C]">Real-Time Asset Catalog</h2>
                  <p className="text-xs text-gray-500">Auto-polling active every 4 seconds. Stock figures guaranteed fresh.</p>
                </div>
                <button
                  onClick={() => loadData()}
                  className="p-2 bg-white rounded-xl border border-[#E8E6E1] text-gray-500 hover:text-[#5B7FAA] hover:border-[#5B7FAA] transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold shadow-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Force Sync
                </button>
              </div>

              {renderFilterPills()}
              {renderAssetGrid(assets)}
            </div>
          )}

          {/* VIEW: MY BORROWINGS */}
          {activeTab === 'my_loans' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-[#2C2C2C]">My Borrowing File</h2>
                  <p className="text-xs text-gray-500">Track due dates and return equipment cleanly with 1-click RESTful PUT.</p>
                </div>
                {!currentUser && (
                  <button
                    onClick={() => setAuthModalOpen(true)}
                    className="px-4 py-2 bg-[#5B7FAA] text-white text-xs font-bold rounded-xl shadow-sm"
                  >
                    Sign In to View
                  </button>
                )}
              </div>

              {!currentUser ? (
                <div className="bg-white rounded-3xl border border-[#E8E6E1] p-12 text-center text-gray-400">
                  <Clock className="w-12 h-12 mx-auto mb-3 opacity-40" />
                  <p className="font-bold text-sm text-[#2C2C2C]">Authentication Session Required</p>
                  <p className="text-xs mt-1">Please sign in to inspect your active equipment loans.</p>
                </div>
              ) : (
                renderLoansTable(loans, 'My Assigned Equipment History', `${loans.length} Total Records`)
              )}
            </div>
          )}

          {/* VIEW: AUDIT LOG HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-[#2C2C2C]">Lending Audit Log</h2>
                  <p className="text-xs text-gray-500">Full immutable ledger of equipment transactions.</p>
                </div>
              </div>
              {renderLoansTable(loans, 'Complete Master Borrowing Ledger', 'Synchronized')}
            </div>
          )}

          {/* VIEW: ADMIN MANAGE ASSETS */}
          {activeTab === 'admin_assets' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {currentUser?.role !== 'admin' ? (
                <div className="bg-white rounded-3xl border border-[#B5655B]/30 p-12 text-center text-[#B5655B]">
                  <ShieldAlert className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-base">Gatekeeper 403 Forbidden</p>
                  <p className="text-xs mt-1 text-gray-500">You are logged in as a staff borrower. Admin role authorization required.</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between bg-white p-6 rounded-3xl border border-[#E8E6E1] shadow-xs">
                    <div>
                      <h2 className="text-lg font-bold text-[#2C2C2C] flex items-center gap-2">
                        <Settings className="w-5 h-5 text-[#D4A373]" /> Inventory Management Console
                      </h2>
                      <p className="text-xs text-gray-500">Enforcing Gatekeeper validations & foreign key ON DELETE RESTRICT locks.</p>
                    </div>
                    <button
                      onClick={() => setManageModalAsset({ isOpen: true, asset: null })}
                      className="px-5 py-2.5 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white font-bold text-xs rounded-2xl shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Provision Asset
                    </button>
                  </div>

                  <div className="bg-white rounded-3xl border border-[#E8E6E1] overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-gray-50 text-gray-400 font-bold uppercase tracking-wider border-b border-[#E8E6E1]">
                        <tr>
                          <th className="px-6 py-3.5">ID</th>
                          <th className="px-6 py-3.5">Equipment Name</th>
                          <th className="px-6 py-3.5">Category</th>
                          <th className="px-6 py-3.5">Location Bay</th>
                          <th className="px-6 py-3.5">Stock Status</th>
                          <th className="px-6 py-3.5 text-right">Admin Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 font-medium">
                        {assets.map((asset) => (
                          <tr key={asset.id} className="hover:bg-gray-50/80 transition-colors">
                            <td className="px-6 py-4 font-mono font-bold text-gray-400">#{asset.id}</td>
                            <td className="px-6 py-4 font-bold text-[#2C2C2C]">{asset.name}</td>
                            <td className="px-6 py-4 text-gray-500">{asset.category}</td>
                            <td className="px-6 py-4 text-gray-500">{asset.location}</td>
                            <td className="px-6 py-4">
                              <span className="font-bold text-[#2C2C2C]">{asset.available_quantity}</span>
                              <span className="text-gray-400"> / {asset.total_quantity} Avail</span>
                            </td>
                            <td className="px-6 py-4 text-right space-x-2">
                              <button
                                onClick={() => setManageModalAsset({ isOpen: true, asset })}
                                className="p-1.5 bg-[#F2F0EA] hover:bg-[#D4A373] text-[#2C2C2C] hover:text-white rounded-lg transition-colors inline-flex items-center justify-center cursor-pointer"
                                title="Edit Asset"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteAsset(asset.id, asset.name)}
                                className="p-1.5 bg-[#B5655B]/10 hover:bg-[#B5655B] text-[#B5655B] hover:text-white rounded-lg transition-colors inline-flex items-center justify-center cursor-pointer"
                                title="Delete Asset"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          )}

          {/* VIEW: ADMIN AI INSIGHTS */}
          {activeTab === 'admin_insights' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {currentUser?.role !== 'admin' ? (
                <div className="bg-white rounded-3xl border border-[#B5655B]/30 p-12 text-center text-[#B5655B]">
                  <ShieldAlert className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-base">Gatekeeper 403 Forbidden</p>
                </div>
              ) : (
                <div className="bg-white p-8 rounded-3xl border border-[#E8E6E1] shadow-xs space-y-6">
                  <div className="flex items-center gap-3 pb-4 border-b border-[#E8E6E1]">
                    <div className="w-12 h-12 bg-[#5B7FAA] rounded-2xl flex items-center justify-center text-white font-bold shadow-md">
                      <BarChart3 className="w-6 h-6 text-[#D4A373]" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-[#2C2C2C]">AI Inventory Optimization Engine</h2>
                      <p className="text-xs text-gray-500">Gemini 2.5 Flash Grounded Analytical Synthesis</p>
                    </div>
                  </div>

                  {reportLoading ? (
                    <div className="py-16 text-center space-y-3">
                      <div className="w-8 h-8 border-4 border-[#5B7FAA] border-t-transparent rounded-full animate-spin mx-auto" />
                      <p className="text-xs font-bold text-[#5B7FAA]">Synthesizing stock turnover & borrowing velocities...</p>
                    </div>
                  ) : (
                    <div className="bg-[#F2F0EA] p-6 rounded-2xl border border-[#E8E6E1] space-y-4">
                      <div className="markdown-body whitespace-pre-wrap font-sans text-sm text-[#2C2C2C] leading-relaxed">
                        {aiReport || 'No report generated.'}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-2">
                    <span className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">
                      Idempotent Ledger Verified • Acid Compliant
                    </span>
                    <button
                      onClick={() => {
                        setReportLoading(true);
                        apiRequest<{ report: string }>('/api/ai/insights')
                          .then((res) => setAiReport(res.report))
                          .finally(() => setReportLoading(false));
                      }}
                      className="px-4 py-2 bg-[#2C2C2C] hover:bg-[#5B7FAA] text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                    >
                      Regenerate AI Report
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
