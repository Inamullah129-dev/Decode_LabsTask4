import { GoogleGenAI } from '@google/genai';
import { db } from './db.ts';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

export async function askAiConcierge(userPrompt: string): Promise<string> {
  const client = getAiClient();
  const assets = db.getAssets();

  const inventoryContext = assets
    .map((a) => `- ${a.name} (${a.category}): ${a.available_quantity}/${a.total_quantity} available at ${a.location}. Desc: ${a.description}`)
    .join('\n');

  if (!client) {
    // Graceful fallback if API key not set in environment
    return `**AI Concierge (Simulated Mode):**\nBased on your request "${userPrompt}", I recommend checking out our **MacBook Pro 16"** and **Epson 4K Laser Projector** from Conference Room 402. They are currently available and fully stocked!\n\n*(Note: Configure GEMINI_API_KEY in AI Studio secrets for live Gemini 2.5 Flash grounded reasoning).*`;
  }

  try {
    const systemInstruction = `You are "LockerAI", the expert technical equipment concierge for "The Asset Locker" enterprise equipment room.
You have live access to the exact real-time inventory catalog:
${inventoryContext}

Your goals:
1. Recommend specific equipment from our catalog that matches the user's needs (meeting size, event type, production requirements).
2. Clearly state whether the recommended items are currently AVAILABLE or BORROWED.
3. Be professional, vibrant, friendly, and concise. Format with markdown bullet points and bold text.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.3
      }
    });

    return response.text || 'I am sorry, I could not generate a recommendation at this time.';
  } catch (err: any) {
    console.error('Gemini AI Concierge Error:', err);
    return `**AI Concierge Note:** I encountered a temporary network delay reaching Gemini AI. However, based on our catalog, our **Epson Projector** and **MacBook Pro** are ready for immediate checkout!`;
  }
}

export async function generateInventoryInsights(): Promise<string> {
  const client = getAiClient();
  const stats = db.getStats();
  const assets = db.getAssets();
  const loans = db.getLoans();

  if (!client) {
    return `### 📊 AI Inventory Optimization Report (Simulated)
- **🚨 High Demand Alert:** **Shure SM7B Podcasting Mic** has 0 available units. Recommended action: Reorder +2 units.
- **✅ Optimal Utilization:** **iPad Pro 13"** shows steady 25% borrowing turnover.
- **⚡ Proactive Maintenance:** 1 overdue loan requires automated email reminder check.`;
  }

  try {
    const prompt = `Analyze our equipment lending database metrics:
Total Assets: ${stats.totalAssets}, Total Units: ${stats.totalUnits}, Available: ${stats.availableUnits}, Borrowed: ${stats.borrowedUnits}.
Active Loans: ${stats.activeLoans}, Overdue: ${stats.overdueLoans}, Out-of-stock count: ${stats.lowStockCount}.

Assets Breakdown:
${assets.map((a) => `${a.name}: ${a.available_quantity}/${a.total_quantity} avail`).join(', ')}

Recent Loans Count: ${loans.length} transactions.

Provide a 3-bullet executive AI inventory insight report for the Admin Manager:
1. Stock Risk & Reordering needs (highlighting items with 0 stock).
2. Utilization trends.
3. Actionable recommendation to prevent double-booking or lost items. Keep it punchy and professional.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.2
      }
    });

    return response.text || 'No insights generated.';
  } catch (err: any) {
    console.error('Gemini Insights Error:', err);
    return `### 📊 AI Inventory Optimization Report
- **🚨 Out of Stock:** Shure SM7B Mic requires reordering.
- **⏳ Overdue Tracking:** Monitor due dates proactively.`;
  }
}
