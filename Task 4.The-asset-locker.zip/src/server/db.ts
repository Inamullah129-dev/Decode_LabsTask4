import fs from 'fs';
import path from 'path';

export interface UserRow {
  id: number;
  email: string;
  password_hash: string;
  full_name: string;
  role: 'borrower' | 'admin';
  created_at: string;
}

export interface AssetRow {
  id: number;
  name: string;
  description: string;
  category: string;
  location: string;
  total_quantity: number;
  available_quantity: number;
  image_url: string;
  created_at: string;
  updated_at: string;
}

export interface LoanRow {
  id: number;
  asset_id: number;
  borrower_id: number;
  borrowed_at: string;
  due_date: string;
  returned_at: string | null;
  status: 'active' | 'returned' | 'overdue';
}

class DatabaseService {
  private dbPath = path.join(process.cwd(), '.asset_locker_data.json');
  private data: {
    users: UserRow[];
    assets: AssetRow[];
    loans: LoanRow[];
    nextIds: { users: number; assets: number; loans: number };
  };

  constructor() {
    this.data = this.loadOrSeed();
  }

  private loadOrSeed() {
    if (fs.existsSync(this.dbPath)) {
      try {
        const raw = fs.readFileSync(this.dbPath, 'utf-8');
        return JSON.parse(raw);
      } catch (e) {
        console.warn('Could not read existing database, reseeding...');
      }
    }

    const initialData = {
      users: [
        {
          id: 1,
          email: 'admin@decode.com',
          password_hash: 'admin123',
          full_name: 'Alex Morgan (Admin)',
          role: 'admin' as const,
          created_at: new Date().toISOString()
        },
        {
          id: 2,
          email: 'borrower@decode.com',
          password_hash: 'borrower123',
          full_name: 'Sarah Jenkins (Borrower)',
          role: 'borrower' as const,
          created_at: new Date().toISOString()
        },
        {
          id: 3,
          email: 'student@decode.com',
          password_hash: 'student123',
          full_name: 'Liam Chen (Student)',
          role: 'borrower' as const,
          created_at: new Date().toISOString()
        }
      ],
      assets: [
        {
          id: 1,
          name: 'MacBook Pro 16" M3 Max',
          description: 'Apple M3 Max chip with 16‑core CPU, 40‑core GPU, 48GB Unified Memory. Ideal for intensive video editing and software engineering.',
          category: 'Laptops',
          location: 'Dev Studio A - Locker 4',
          total_quantity: 5,
          available_quantity: 4,
          image_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 2,
          name: 'Sony Alpha a7S III Mirrorless Camera',
          description: 'Full-frame 12.1MP sensor optimized for 4K 120p video recording. Includes 24-70mm G Master lens and dual SD cards.',
          category: 'A/V Equipment',
          location: 'Media Bay 2',
          total_quantity: 3,
          available_quantity: 1,
          image_url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 3,
          name: 'Epson PowerLite 4K Laser Projector',
          description: 'High lumen output laser projector with HDMI and wireless Miracast projection. Perfect for auditorium and board meetings.',
          category: 'Presentation',
          location: 'Conference Room 402',
          total_quantity: 2,
          available_quantity: 2,
          image_url: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 4,
          name: 'iPad Pro 13" (M4) + Apple Pencil Pro',
          description: 'Ultra-thin Tandem OLED display with M4 chip. Preloaded with Procreate, Figma, and Affinity Designer for digital artists.',
          category: 'Tablets',
          location: 'Design Hub - Desk 1',
          total_quantity: 8,
          available_quantity: 6,
          image_url: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 5,
          name: 'Shure SM7B Vocal Dynamic Microphone',
          description: 'Studio-grade vocal microphone with cloudlifter preamp attached. Shielded against electromagnetic hum. High demand item.',
          category: 'Audio',
          location: 'Podcast Studio B',
          total_quantity: 4,
          available_quantity: 0,
          image_url: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 6,
          name: 'Meta Quest 3 VR Headset (512GB)',
          description: 'Mixed reality headset with 4K+ Infinite Display and Touch Plus controllers. Used for spatial computing testing.',
          category: 'VR/AR',
          location: 'Innovation Lab Storage',
          total_quantity: 4,
          available_quantity: 3,
          image_url: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 7,
          name: 'Dell UltraSharp 32" 4K USB-C Hub Monitor',
          description: 'IPS Black technology with 98% DCI-P3 color coverage and 90W power delivery over single USB-C cable.',
          category: 'Displays',
          location: 'IT Supply Cabinet',
          total_quantity: 6,
          available_quantity: 5,
          image_url: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 8,
          name: 'Bose QuietComfort Ultra Wireless Headphones',
          description: 'Spatial audio immersion with world-class noise cancellation and 24-hour battery life.',
          category: 'Accessories',
          location: 'Front Desk Lending',
          total_quantity: 10,
          available_quantity: 8,
          image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ],
      loans: [
        {
          id: 1,
          asset_id: 1,
          borrower_id: 2,
          borrowed_at: new Date(Date.now() - 86400000 * 2).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 5).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 2,
          asset_id: 2,
          borrower_id: 2,
          borrowed_at: new Date(Date.now() - 86400000 * 1).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 3).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 3,
          asset_id: 2,
          borrower_id: 3,
          borrowed_at: new Date(Date.now() - 86400000 * 3).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 4).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 4,
          asset_id: 5,
          borrower_id: 2,
          borrowed_at: new Date(Date.now() - 86400000 * 4).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 3).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 5,
          asset_id: 5,
          borrower_id: 3,
          borrowed_at: new Date(Date.now() - 86400000 * 2).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 2).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 6,
          asset_id: 5,
          borrower_id: 1,
          borrowed_at: new Date(Date.now() - 86400000 * 1).toISOString(),
          due_date: new Date(Date.now() + 86400000 * 6).toISOString(),
          returned_at: null,
          status: 'active' as const
        },
        {
          id: 7,
          asset_id: 5,
          borrower_id: 3,
          borrowed_at: new Date(Date.now() - 86400000 * 5).toISOString(),
          due_date: new Date(Date.now() - 86400000 * 1).toISOString(), // Overdue example
          returned_at: null,
          status: 'overdue' as const
        },
        {
          id: 8,
          asset_id: 4,
          borrower_id: 2,
          borrowed_at: new Date(Date.now() - 86400000 * 10).toISOString(),
          due_date: new Date(Date.now() - 86400000 * 3).toISOString(),
          returned_at: new Date(Date.now() - 86400000 * 4).toISOString(),
          status: 'returned' as const
        }
      ],
      nextIds: { users: 4, assets: 9, loans: 9 }
    };

    this.save(initialData);
    return initialData;
  }

  private save(data = this.data) {
    try {
      fs.writeFileSync(this.dbPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write db file:', e);
    }
  }

  // --- Users ---
  public getUsers(): UserRow[] {
    return this.data.users;
  }

  public getUserById(id: number): UserRow | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public getUserByEmail(email: string): UserRow | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(email: string, password_hash: string, full_name: string, role: 'borrower' | 'admin'): UserRow {
    if (this.getUserByEmail(email)) {
      throw new Error('User with this email already exists');
    }
    const newUser: UserRow = {
      id: this.data.nextIds.users++,
      email,
      password_hash,
      full_name,
      role,
      created_at: new Date().toISOString()
    };
    this.data.users.push(newUser);
    this.save();
    return newUser;
  }

  // --- Assets ---
  public getAssets(query?: string, category?: string, status?: string): AssetRow[] {
    let list = [...this.data.assets];
    if (query && query.trim() !== '') {
      const q = query.toLowerCase();
      list = list.filter((a) => a.name.toLowerCase().includes(q) || a.description.toLowerCase().includes(q) || a.location.toLowerCase().includes(q));
    }
    if (category && category !== 'All') {
      list = list.filter((a) => a.category.toLowerCase() === category.toLowerCase());
    }
    if (status) {
      if (status === 'available') {
        list = list.filter((a) => a.available_quantity > 0);
      } else if (status === 'borrowed') {
        list = list.filter((a) => a.available_quantity === 0);
      }
    }
    return list.sort((a, b) => a.id - b.id);
  }

  public getAssetById(id: number): AssetRow | undefined {
    return this.data.assets.find((a) => a.id === id);
  }

  public createAsset(asset: Omit<AssetRow, 'id' | 'created_at' | 'updated_at'>): AssetRow {
    if (asset.total_quantity < 0 || asset.available_quantity < 0) {
      throw new Error('Quantity cannot be negative');
    }
    if (asset.available_quantity > asset.total_quantity) {
      throw new Error('Available quantity cannot exceed total quantity');
    }
    const newAsset: AssetRow = {
      ...asset,
      id: this.data.nextIds.assets++,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.data.assets.push(newAsset);
    this.save();
    return newAsset;
  }

  public updateAsset(id: number, updates: Partial<Omit<AssetRow, 'id' | 'created_at'>>): AssetRow {
    const idx = this.data.assets.findIndex((a) => a.id === id);
    if (idx === -1) throw new Error('Asset not found');

    const current = this.data.assets[idx];
    const newTotal = updates.total_quantity !== undefined ? updates.total_quantity : current.total_quantity;
    const newAvail = updates.available_quantity !== undefined ? updates.available_quantity : current.available_quantity;

    if (newTotal < 0 || newAvail < 0) {
      throw new Error('Quantity constraint failure: Stock cannot be negative');
    }
    if (newAvail > newTotal) {
      throw new Error('Available quantity cannot exceed total quantity');
    }

    const updated: AssetRow = {
      ...current,
      ...updates,
      updated_at: new Date().toISOString()
    };
    this.data.assets[idx] = updated;
    this.save();
    return updated;
  }

  public deleteAsset(id: number): boolean {
    // Check constraint: RESTRICT deletion if active loans exist
    const activeLoans = this.data.loans.filter((l) => l.asset_id === id && (l.status === 'active' || l.status === 'overdue'));
    if (activeLoans.length > 0) {
      throw new Error('CONSTRAINT_RESTRICT: Cannot delete asset with active or overdue borrowings');
    }
    const idx = this.data.assets.findIndex((a) => a.id === id);
    if (idx === -1) return false;
    this.data.assets.splice(idx, 1);
    this.save();
    return true;
  }

  // --- Loans ---
  public getLoans(borrowerId?: number, status?: string): (LoanRow & { asset: AssetRow; borrower: UserRow })[] {
    let list = [...this.data.loans];
    if (borrowerId) {
      list = list.filter((l) => l.borrower_id === borrowerId);
    }
    if (status && status !== 'All') {
      list = list.filter((l) => l.status === status);
    }
    return list
      .map((loan) => {
        const asset = this.getAssetById(loan.asset_id) || {
          id: loan.asset_id,
          name: 'Unknown Asset (Deleted)',
          description: '',
          category: 'Other',
          location: '',
          total_quantity: 0,
          available_quantity: 0,
          image_url: '',
          created_at: '',
          updated_at: ''
        };
        const borrower = this.getUserById(loan.borrower_id) || {
          id: loan.borrower_id,
          email: 'unknown@decode.com',
          password_hash: '',
          full_name: 'Unknown User',
          role: 'borrower',
          created_at: ''
        };
        return { ...loan, asset, borrower };
      })
      .sort((a, b) => new Date(b.borrowed_at).getTime() - new Date(a.borrowed_at).getTime());
  }

  public getLoanById(id: number): LoanRow | undefined {
    return this.data.loans.find((l) => l.id === id);
  }

  public borrowAsset(assetId: number, borrowerId: number, dueDateStr?: string): LoanRow {
    const asset = this.getAssetById(assetId);
    if (!asset) throw new Error('Asset not found');

    if (asset.available_quantity <= 0) {
      throw new Error('OUT_OF_STOCK: Asset is currently unavailable');
    }

    // Check unique active constraint (asset_id, borrower_id, status)
    const existingActive = this.data.loans.find(
      (l) => l.asset_id === assetId && l.borrower_id === borrowerId && (l.status === 'active' || l.status === 'overdue')
    );
    if (existingActive) {
      throw new Error('DUPLICATE_LOAN_CONFLICT: You already have an active borrowing for this asset');
    }

    // Decrement available quantity (ACID transaction simulation)
    asset.available_quantity -= 1;
    asset.updated_at = new Date().toISOString();

    const due = dueDateStr || new Date(Date.now() + 86400000 * 7).toISOString(); // Default 7 days
    const newLoan: LoanRow = {
      id: this.data.nextIds.loans++,
      asset_id: assetId,
      borrower_id: borrowerId,
      borrowed_at: new Date().toISOString(),
      due_date: due,
      returned_at: null,
      status: 'active'
    };

    this.data.loans.push(newLoan);
    this.save();
    return newLoan;
  }

  public returnAsset(loanId: number, borrowerId?: number, isAdmin = false): { loan: LoanRow; alreadyReturned: boolean } {
    const loan = this.getLoanById(loanId);
    if (!loan) throw new Error('Loan record not found');

    if (!isAdmin && borrowerId !== undefined && loan.borrower_id !== borrowerId) {
      throw new Error('FORBIDDEN: You cannot return an asset borrowed by another user');
    }

    // IDEMPOTENCY CHECK (PRD 7.3 & 7.4)
    if (loan.status === 'returned') {
      return { loan, alreadyReturned: true };
    }

    // Increment asset stock
    const asset = this.getAssetById(loan.asset_id);
    if (asset) {
      if (asset.available_quantity < asset.total_quantity) {
        asset.available_quantity += 1;
        asset.updated_at = new Date().toISOString();
      }
    }

    loan.returned_at = new Date().toISOString();
    loan.status = 'returned';

    this.save();
    return { loan, alreadyReturned: false };
  }

  public getStats() {
    const totalAssets = this.data.assets.length;
    const totalUnits = this.data.assets.reduce((sum, a) => sum + a.total_quantity, 0);
    const availableUnits = this.data.assets.reduce((sum, a) => sum + a.available_quantity, 0);
    const borrowedUnits = totalUnits - availableUnits;
    const activeLoans = this.data.loans.filter((l) => l.status === 'active' || l.status === 'overdue').length;
    const overdueLoans = this.data.loans.filter((l) => l.status === 'overdue').length;
    const lowStockCount = this.data.assets.filter((a) => a.available_quantity === 0).length;

    return {
      totalAssets,
      totalUnits,
      availableUnits,
      borrowedUnits,
      activeLoans,
      overdueLoans,
      lowStockCount
    };
  }

  public getCategories(): string[] {
    const cats = new Set(this.data.assets.map((a) => a.category));
    return ['All', ...Array.from(cats)];
  }
}

export const db = new DatabaseService();
