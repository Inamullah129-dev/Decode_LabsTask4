import React from 'react';
import { LayoutDashboard, Package, Clock, History, Settings, BarChart3, ShieldAlert } from 'lucide-react';
import { User } from '../types.ts';

export type NavTab = 'catalog' | 'dashboard' | 'my_loans' | 'history' | 'admin_assets' | 'admin_insights';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentUser: User | null;
  onOpenAuth: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab, currentUser, onOpenAuth }) => {
  const isAdmin = currentUser?.role === 'admin';

  const navItem = (tab: NavTab, label: string, Icon: React.ComponentType<{ className?: string }>) => {
    const isActive = activeTab === tab;
    return (
      <button
        onClick={() => onSelectTab(tab)}
        className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all text-left ${
          isActive
            ? 'bg-[#5B7FAA] text-white shadow-md font-semibold'
            : 'text-gray-400 hover:text-white hover:bg-white/5'
        }`}
      >
        <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-gray-400'}`} />
        <span>{label}</span>
      </button>
    );
  };

  return (
    <aside className="w-64 bg-[#2C2C2C] shrink-0 flex flex-col justify-between py-8 px-6 text-white select-none">
      <div className="space-y-8">
        <div>
          <div className="flex items-center gap-2.5 mb-8 px-2">
            <div className="w-9 h-9 bg-[#5B7FAA] rounded-xl flex items-center justify-center font-bold text-white shadow-lg tracking-wider text-base">
              AL
            </div>
            <div>
              <h1 className="text-white font-bold text-lg tracking-tight leading-none">Asset Locker</h1>
              <span className="text-[10px] font-semibold text-[#D4A373] tracking-widest uppercase">DecodeLabs v1.0</span>
            </div>
          </div>

          <p className="text-[11px] font-bold text-gray-500 uppercase tracking-widest px-3 mb-2">Lending Portal</p>
          <nav className="space-y-1">
            {navItem('catalog', 'Asset Catalog', Package)}
            {navItem('dashboard', 'Overview Grid', LayoutDashboard)}
            {navItem('my_loans', 'My Borrowings', Clock)}
            {navItem('history', 'Audit Log History', History)}
          </nav>
        </div>

        {isAdmin && (
          <div className="pt-6 border-t border-gray-700/80 animate-in fade-in duration-300">
            <p className="text-[11px] font-bold text-[#D4A373] uppercase tracking-widest px-3 mb-2 flex items-center gap-1.5">
              <ShieldAlert className="w-3 h-3 text-[#D4A373]" /> Admin Gatekeeper
            </p>
            <nav className="space-y-1">
              {navItem('admin_assets', 'Manage Assets', Settings)}
              {navItem('admin_insights', 'AI Inventory Report', BarChart3)}
            </nav>
          </div>
        )}
      </div>

      <div className="pt-6 border-t border-gray-800">
        {currentUser ? (
          <div className="flex items-center gap-3 px-2">
            <div className="w-9 h-9 rounded-full bg-[#E8E6E1] text-[#2C2C2C] flex items-center justify-center text-xs font-black shadow-inner">
              {currentUser.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-white text-xs font-bold truncate">{currentUser.full_name}</span>
              <span className="text-[#D4A373] text-[10px] font-semibold uppercase">{currentUser.role}</span>
            </div>
          </div>
        ) : (
          <button
            onClick={onOpenAuth}
            className="w-full py-2.5 px-3 bg-[#5B7FAA]/20 hover:bg-[#5B7FAA] text-[#5B7FAA] hover:text-white rounded-xl text-xs font-bold border border-[#5B7FAA]/40 transition-all text-center"
          >
            Sign In for Lending
          </button>
        )}
      </div>
    </aside>
  );
};
