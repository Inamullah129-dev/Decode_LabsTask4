import React from 'react';
import { Search, AlertCircle, Plus, LogIn, LogOut, Bot } from 'lucide-react';
import { User } from '../types.ts';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  overdueCount: number;
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenAi: () => void;
  onNewRequest: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  onSearchChange,
  overdueCount,
  currentUser,
  onOpenAuth,
  onLogout,
  onOpenAi,
  onNewRequest
}) => {
  return (
    <header className="h-16 border-b border-[#E8E6E1] bg-white px-8 flex items-center justify-between shrink-0 shadow-xs">
      <div className="relative w-96">
        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400">
          <Search className="w-4 h-4" />
        </span>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search inventory (Laptops, Cameras, VR...)"
          className="w-full pl-10 pr-4 py-2 bg-[#F2F0EA] border-none rounded-full text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none text-[#2C2C2C] placeholder:text-gray-400"
        />
      </div>

      <div className="flex items-center gap-4">
        {overdueCount > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#B5655B]/10 text-[#B5655B] text-xs font-semibold rounded-full border border-[#B5655B]/20 animate-pulse">
            <AlertCircle className="w-3.5 h-3.5 text-[#B5655B]" />
            <span>{overdueCount} Items Overdue</span>
          </div>
        )}

        <button
          onClick={onOpenAi}
          className="px-3.5 py-1.5 bg-[#F2F0EA] hover:bg-[#E8E6E1] text-[#2C2C2C] rounded-full text-xs font-bold border border-[#E8E6E1] flex items-center gap-1.5 transition-all shadow-xs hover:border-[#5B7FAA]"
          title="Ask LockerAI Concierge"
        >
          <Bot className="w-3.5 h-3.5 text-[#5B7FAA]" />
          <span>LockerAI Concierge</span>
        </button>

        <button
          onClick={onNewRequest}
          className="px-4 py-2 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white rounded-full text-xs font-bold shadow-sm flex items-center gap-1 transition-all hover:scale-105 active:scale-95 cursor-pointer"
        >
          <span>New Request</span>
          <Plus className="w-3.5 h-3.5" />
        </button>

        <div className="h-6 w-px bg-[#E8E6E1] mx-1" />

        {currentUser ? (
          <div className="flex items-center gap-2.5">
            <div className="flex flex-col text-right">
              <span className="text-xs font-bold text-[#2C2C2C] leading-none">{currentUser.full_name}</span>
              <span className="text-[10px] font-bold text-[#5B7FAA] uppercase tracking-wider">{currentUser.role}</span>
            </div>
            <button
              onClick={onLogout}
              className="p-1.5 text-gray-400 hover:text-[#B5655B] hover:bg-[#B5655B]/10 rounded-full transition-colors"
              title="Sign out session"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenAuth}
            className="px-4 py-1.5 bg-[#2C2C2C] hover:bg-[#2C2C2C]/80 text-white rounded-full text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </header>
  );
};
