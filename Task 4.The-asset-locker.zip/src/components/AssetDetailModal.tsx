import React, { useState } from 'react';
import { Asset } from '../types.ts';
import { Package, MapPin, Layers, CheckCircle2, AlertCircle, Calendar, ShieldAlert } from 'lucide-react';

interface AssetDetailModalProps {
  asset: Asset | null;
  isOpen: boolean;
  onClose: () => void;
  onBorrow: (asset: Asset, dueDate: string) => void;
  isBorrowing: boolean;
  userRole?: string;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  asset,
  isOpen,
  onClose,
  onBorrow,
  isBorrowing,
  userRole
}) => {
  const [days, setDays] = useState(7);

  if (!isOpen || !asset) return null;

  const isAvailable = asset.available_quantity > 0;
  const dueDate = new Date(Date.now() + 86400000 * days).toISOString();

  const handleBorrowClick = () => {
    onBorrow(asset, dueDate);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#F2F0EA] rounded-3xl border border-[#E8E6E1] shadow-2xl overflow-hidden text-[#2C2C2C] flex flex-col md:flex-row max-h-[90vh]">
        <div className="w-full md:w-1/2 bg-[#E8E6E1] relative shrink-0 min-h-[240px] md:min-h-[full]">
          {asset.image_url ? (
            <img src={asset.image_url} alt={asset.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <Package className="w-16 h-16" />
            </div>
          )}
          <div className="absolute top-4 left-4">
            <span className="px-3 py-1 bg-black/70 backdrop-blur-md text-white font-mono text-[11px] font-bold rounded-full">
              ID: ASSET-{asset.id}
            </span>
          </div>
        </div>

        <div className="w-full md:w-1/2 p-7 flex flex-col justify-between overflow-y-auto bg-white">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#5B7FAA] flex items-center gap-1">
                <Layers className="w-3.5 h-3.5" /> {asset.category}
              </span>
              {isAvailable ? (
                <span className="px-2.5 py-0.5 bg-[#D4A373] text-white text-[10px] font-bold rounded-full">
                  AVAILABLE
                </span>
              ) : (
                <span className="px-2.5 py-0.5 bg-[#B5655B] text-white text-[10px] font-bold rounded-full">
                  OUT OF STOCK
                </span>
              )}
            </div>

            <h2 className="text-xl font-bold text-[#2C2C2C] leading-snug">{asset.name}</h2>

            <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 bg-[#F2F0EA] px-3 py-2 rounded-xl">
              <MapPin className="w-4 h-4 text-[#5B7FAA]" />
              <span>Location: {asset.location}</span>
            </div>

            <div className="pt-2 border-t border-[#E8E6E1]">
              <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Hardware Specification & Notes</h4>
              <p className="text-xs text-gray-600 leading-relaxed font-normal">{asset.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-[#F2F0EA] rounded-xl border border-[#E8E6E1]">
                <span className="block text-[10px] font-bold text-gray-400 uppercase">Total Inventory</span>
                <span className="text-lg font-bold text-[#2C2C2C]">{asset.total_quantity} Units</span>
              </div>
              <div className="p-3 bg-[#F2F0EA] rounded-xl border border-[#E8E6E1]">
                <span className="block text-[10px] font-bold text-gray-400 uppercase">Available Ready</span>
                <span className={`text-lg font-bold ${isAvailable ? 'text-[#5A7D6B]' : 'text-[#B5655B]'}`}>
                  {asset.available_quantity} Units
                </span>
              </div>
            </div>

            {isAvailable && (
              <div className="pt-2">
                <label className="block text-[11px] font-bold text-gray-500 uppercase mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-[#5B7FAA]" /> Lending Duration
                </label>
                <select
                  value={days}
                  onChange={(e) => setDays(Number(e.target.value))}
                  className="w-full p-2.5 bg-[#F2F0EA] border border-[#E8E6E1] rounded-xl text-xs font-semibold text-[#2C2C2C] outline-none focus:border-[#5B7FAA]"
                >
                  <option value={3}>3 Days Loan</option>
                  <option value={7}>7 Days Standard Loan</option>
                  <option value={14}>14 Days Extended Project Loan</option>
                  <option value={30}>30 Days Semester/Department Loan</option>
                </select>
              </div>
            )}
          </div>

          <div className="pt-6 mt-6 border-t border-[#E8E6E1] flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 py-3 px-4 bg-[#F2F0EA] hover:bg-[#E8E6E1] text-[#2C2C2C] font-bold text-xs rounded-xl transition-colors"
            >
              Close Window
            </button>
            {isAvailable ? (
              <button
                onClick={handleBorrowClick}
                disabled={isBorrowing}
                className="flex-1 py-3 px-4 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                {isBorrowing ? 'Confirming Loan...' : 'Confirm Checkout'}
              </button>
            ) : (
              <button disabled className="flex-1 py-3 px-4 bg-gray-100 text-gray-400 font-bold text-xs rounded-xl cursor-not-allowed">
                Currently Lent Out
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
