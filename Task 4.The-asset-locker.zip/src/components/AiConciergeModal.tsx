import React, { useState } from 'react';
import { Bot, Sparkles, Send, ArrowRight } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';

interface AiConciergeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiConciergeModal: React.FC<AiConciergeModalProps> = ({ isOpen, onClose }) => {
  const [prompt, setPrompt] = useState('');
  const [reply, setReply] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (customText?: string) => {
    const textToSend = customText || prompt;
    if (!textToSend.trim()) return;

    setLoading(true);
    setReply(null);

    try {
      const data = await apiRequest<{ reply: string }>('/api/ai/concierge', {
        method: 'POST',
        body: JSON.stringify({ prompt: textToSend })
      });
      setReply(data.reply);
    } catch (err: any) {
      setReply(`**Concierge Error:** Could not connect to LockerAI server. (${err.message})`);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    'I need equipment for a 4K podcast interview with 2 speakers.',
    'What laptops do we have with at least 32GB RAM available right now?',
    'I am doing a design sprint auditorium presentation. What should I borrow?'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#F2F0EA] rounded-3xl border border-[#E8E6E1] shadow-2xl overflow-hidden text-[#2C2C2C] flex flex-col max-h-[85vh]">
        <div className="bg-[#2C2C2C] p-6 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#5B7FAA] rounded-2xl flex items-center justify-center font-bold text-white shadow-lg">
              <Bot className="w-6 h-6 text-[#D4A373]" />
            </div>
            <div>
              <h2 className="font-bold text-lg leading-tight">LockerAI Concierge</h2>
              <p className="text-xs text-[#D4A373] font-medium">Powered by Gemini 2.5 Grounded Catalog Reasoning</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white font-bold text-xl px-2">
            ✕
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-6 bg-white">
          {!reply && !loading && (
            <div className="bg-[#F2F0EA] p-5 rounded-2xl border border-[#E8E6E1] space-y-3">
              <p className="text-xs font-bold text-[#2C2C2C] flex items-center gap-1.5 uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-[#D4A373]" /> What can LockerAI help you find?
              </p>
              <p className="text-xs text-gray-600">
                Ask natural language questions about your technical project, meeting, or event. LockerAI cross-references real-time stock levels.
              </p>
              <div className="space-y-2 pt-1">
                {samplePrompts.map((sp, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setPrompt(sp);
                      handleSend(sp);
                    }}
                    className="w-full text-left p-2.5 bg-white hover:bg-[#5B7FAA]/10 hover:border-[#5B7FAA] border border-[#E8E6E1] rounded-xl text-xs font-medium text-[#2C2C2C] transition-all flex items-center justify-between group cursor-pointer shadow-xs"
                  >
                    <span>"{sp}"</span>
                    <ArrowRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-[#5B7FAA]" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {loading && (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-center">
              <div className="w-10 h-10 border-4 border-[#5B7FAA] border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-bold text-[#5B7FAA] animate-pulse">Scanning 124 asset records & analyzing requirements...</p>
            </div>
          )}

          {reply && (
            <div className="bg-[#F2F0EA] p-6 rounded-2xl border border-[#5B7FAA]/30 shadow-xs text-xs leading-relaxed space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b border-[#E8E6E1]">
                <Bot className="w-4 h-4 text-[#5B7FAA]" />
                <span className="font-bold text-[#2C2C2C]">LockerAI Recommendation</span>
              </div>
              <div className="markdown-body whitespace-pre-wrap font-sans text-sm text-[#2C2C2C]">
                {reply}
              </div>
              <button
                onClick={() => setReply(null)}
                className="text-xs font-bold text-[#5B7FAA] pt-2 block hover:underline cursor-pointer"
              >
                ← Ask another question
              </button>
            </div>
          )}
        </div>

        <div className="p-4 bg-[#F2F0EA] border-t border-[#E8E6E1] shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your equipment requirements..."
              className="flex-1 px-4 py-3 bg-white border border-[#E8E6E1] rounded-2xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="px-5 py-3 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white font-bold text-xs rounded-2xl shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer"
            >
              <span>Ask AI</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
