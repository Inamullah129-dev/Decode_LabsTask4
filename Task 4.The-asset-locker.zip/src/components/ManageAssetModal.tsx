import React, { useState, useEffect } from 'react';
import { Asset } from '../types.ts';
import { Package, Save, Layers, MapPin, Hash, Image as ImageIcon, Sparkles } from 'lucide-react';

interface ManageAssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (assetData: Partial<Asset>) => Promise<void>;
  editingAsset: Asset | null;
}

export const ManageAssetModal: React.FC<ManageAssetModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingAsset
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Laptops');
  const [location, setLocation] = useState('');
  const [totalQuantity, setTotalQuantity] = useState(1);
  const [availableQuantity, setAvailableQuantity] = useState(1);
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (editingAsset) {
      setName(editingAsset.name);
      setCategory(editingAsset.category);
      setLocation(editingAsset.location);
      setTotalQuantity(editingAsset.total_quantity);
      setAvailableQuantity(editingAsset.available_quantity);
      setDescription(editingAsset.description);
      setImageUrl(editingAsset.image_url || '');
    } else {
      setName('');
      setCategory('Laptops');
      setLocation('Tech Locker A1');
      setTotalQuantity(3);
      setAvailableQuantity(3);
      setDescription('');
      setImageUrl('');
    }
  }, [editingAsset, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (availableQuantity > totalQuantity) {
      setError('Available quantity cannot be greater than Total quantity.');
      return;
    }
    if (totalQuantity < 0 || availableQuantity < 0) {
      setError('Quantities cannot be negative (Database constraint check).');
      return;
    }

    setLoading(true);
    try {
      await onSave({
        name,
        category,
        location,
        total_quantity: Number(totalQuantity),
        available_quantity: Number(availableQuantity),
        description,
        image_url: imageUrl
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save asset details');
    } finally {
      setLoading(false);
    }
  };

  const presetSample = () => {
    setName('DJI RS 4 Pro Gimbal Stabilizer');
    setCategory('A/V Equipment');
    setLocation('Media Room B - Shelf 2');
    setTotalQuantity(2);
    setAvailableQuantity(2);
    setDescription('Automated axis locks with carbon fiber construction. Payload capacity 4.5kg for heavy cinema rigs.');
    setImageUrl('https://images.unsplash.com/photo-1589254065878-42c9da997008?auto=format&fit=crop&w=800&q=80');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-[#F2F0EA] rounded-3xl border border-[#E8E6E1] shadow-2xl overflow-hidden text-[#2C2C2C]">
        <div className="bg-[#2C2C2C] p-6 text-white flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#D4A373] rounded-xl flex items-center justify-center font-bold text-white shadow-md">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-lg leading-tight">
                {editingAsset ? 'Edit Asset Record' : 'Provision New Asset'}
              </h2>
              <p className="text-xs text-gray-400">Admin Gatekeeper • RESTful Inventory API</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white font-bold text-xl px-2">
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {!editingAsset && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={presetSample}
                className="text-xs font-bold text-[#5B7FAA] flex items-center gap-1 hover:underline cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-[#D4A373]" /> Fill Sample Spec
              </button>
            </div>
          )}

          {error && (
            <div className="p-3 bg-[#B5655B]/10 border border-[#B5655B]/30 rounded-xl text-xs font-medium text-[#B5655B]">
              ⚠️ {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Equipment Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. MacBook Pro 16 M3 Max"
              className="w-full px-4 py-2.5 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2.5 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
              >
                <option value="Laptops">Laptops</option>
                <option value="A/V Equipment">A/V Equipment</option>
                <option value="Presentation">Presentation</option>
                <option value="Tablets">Tablets</option>
                <option value="Audio">Audio</option>
                <option value="VR/AR">VR/AR</option>
                <option value="Displays">Displays</option>
                <option value="Accessories">Accessories</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Locker / Room Location</label>
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Media Bay 4"
                className="w-full px-4 py-2.5 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Total Stock Quantity</label>
              <input
                type="number"
                min={0}
                required
                value={totalQuantity}
                onChange={(e) => setTotalQuantity(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Available Quantity</label>
              <input
                type="number"
                min={0}
                max={totalQuantity}
                required
                value={availableQuantity}
                onChange={(e) => setAvailableQuantity(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-sm font-bold text-[#5B7FAA]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Image URL (Unsplash or Direct CDN)</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://images.unsplash.com/photo-..."
              className="w-full px-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-xs font-mono text-gray-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Description & Tech Specs</label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Include chipset, memory, ports, or special handling instructions..."
              className="w-full px-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-xs"
            />
          </div>

          <div className="pt-4 border-t border-[#E8E6E1] flex gap-3 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 bg-white hover:bg-gray-50 text-[#2C2C2C] font-bold text-xs rounded-xl border border-[#E8E6E1]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Commiting...' : 'Save Asset Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
