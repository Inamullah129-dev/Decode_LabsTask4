import React, { useState } from 'react';
import { apiRequest, saveAuthSession } from '../lib/api.ts';
import { User } from '../types.ts';
import { Lock, Mail, User as UserIcon, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
      const body = isRegister ? { email, password, full_name: fullName } : { email, password };
      const data = await apiRequest<{ token: string; user: User }>(endpoint, {
        method: 'POST',
        body: JSON.stringify(body)
      });

      saveAuthSession(data.token, data.user);
      onSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const quickDemoLogin = async (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setError('');
    setLoading(true);

    try {
      const data = await apiRequest<{ token: string; user: User }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: demoEmail, password: demoPass })
      });
      saveAuthSession(data.token, data.user);
      onSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#F2F0EA] rounded-3xl border border-[#E8E6E1] shadow-2xl overflow-hidden text-[#2C2C2C]">
        <div className="bg-[#2C2C2C] p-6 text-white flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#5B7FAA] rounded-xl flex items-center justify-center font-bold text-white shadow-md">
              AL
            </div>
            <div>
              <h2 className="font-bold text-lg leading-tight">The Asset Locker</h2>
              <p className="text-xs text-gray-400">Enterprise Equipment Lending Portal</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white font-bold text-xl px-2">
            ✕
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-[#E8E6E1] shadow-sm">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#D4A373]" /> Quick Demo Logins
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => quickDemoLogin('admin@decode.com', 'admin123')}
                className="py-2 px-3 bg-[#2C2C2C] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 hover:bg-[#5B7FAA] transition-colors"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4A373]" /> Admin Access
              </button>
              <button
                type="button"
                onClick={() => quickDemoLogin('borrower@decode.com', 'borrower123')}
                className="py-2 px-3 bg-white text-[#2C2C2C] border border-[#E8E6E1] text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 hover:border-[#5B7FAA] hover:text-[#5B7FAA] transition-colors shadow-sm"
              >
                <UserIcon className="w-3.5 h-3.5 text-[#5B7FAA]" /> Staff Borrower
              </button>
            </div>
          </div>

          <div className="flex border-b border-[#E8E6E1]">
            <button
              type="button"
              onClick={() => setIsRegister(false)}
              className={`flex-1 pb-3 text-sm font-bold text-center border-b-2 transition-all ${
                !isRegister ? 'border-[#5B7FAA] text-[#5B7FAA]' : 'border-transparent text-gray-400'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setIsRegister(true)}
              className={`flex-1 pb-3 text-sm font-bold text-center border-b-2 transition-all ${
                isRegister ? 'border-[#5B7FAA] text-[#5B7FAA]' : 'border-transparent text-gray-400'
              }`}
            >
              New Account
            </button>
          </div>

          {error && (
            <div className="p-3 bg-[#B5655B]/10 border border-[#B5655B]/30 rounded-xl text-xs font-medium text-[#B5655B]">
              ⚠️ {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Jordan Smith"
                    className="w-full pl-10 pr-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@decode.com"
                  className="w-full pl-10 pr-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 bg-white border border-[#E8E6E1] rounded-xl text-sm focus:ring-2 focus:ring-[#5B7FAA] outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-[#5B7FAA] hover:bg-[#5B7FAA]/90 text-white rounded-xl text-sm font-bold shadow-md flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span>Processing IPO Auth...</span>
              ) : (
                <>
                  <span>{isRegister ? 'Register & Enter Locker' : 'Authenticate Session'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
