import React from 'react';
import { Asset } from '../types.ts';
import { Package, MapPin, CheckCircle2, AlertCircle } from 'lucide-react';

interface AssetCardProps {
  asset: Asset;
  onBorrow: (asset: Asset) => void;
  onSelect: (asset: Asset) => void;
  isBorrowing: boolean;
}

export const AssetCard: React.FC<AssetCardProps> = ({ asset, onBorrow, onSelect, isBorrowing }) => {
  const isAvailable = asset.available_quantity > 0;

  return (
    <div className="bg-white p-5 rounded-3xl border border-[#E8E6E1] flex flex-col gap-3.5 group shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden">
      <div
        onClick={() => onSelect(asset)}
        className="h-36 bg-[#F2F0EA] rounded-2xl relative overflow-hidden cursor-pointer shrink-0 border border-[#E8E6E1]/60 group-hover:border-[#5B7FAA]/40 transition-colors"
      >
        {asset.image_url ? (
          <img
            src={asset.image_url}
            alt={asset.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            <Package className="w-12 h-12" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
          <span className="text-[11px] font-bold text-white uppercase tracking-wider bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-lg">
            Inspect Specs →
          </span>
        </div>
      </div>

      <div className="flex justify-between items-start gap-2">
        <div className="flex-1 overflow-hidden" onClick={() => onSelect(asset)}>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight truncate">
            {asset.category} • {asset.location}
          </p>
          <h3 className="font-bold text-sm text-[#2C2C2C] group-hover:text-[#5B7FAA] transition-colors line-clamp-1 cursor-pointer">
            {asset.name}
          </h3>
        </div>

        {isAvailable ? (
          <span className="px-2.5 py-1 bg-[#D4A373] text-white text-[10px] font-bold rounded-full shrink-0 flex items-center gap-1 shadow-xs">
            <CheckCircle2 className="w-3 h-3" /> AVAILABLE
          </span>
        ) : (
          <span className="px-2.5 py-1 bg-[#B5655B] text-white text-[10px] font-bold rounded-full shrink-0 flex items-center gap-1 shadow-xs">
            <AlertCircle className="w-3 h-3" /> BORROWED
          </span>
        )}
      </div>

      <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed h-8 font-normal">{asset.description}</p>

      <div className="pt-2.5 border-t border-[#E8E6E1]/80 flex items-center justify-between mt-auto">
        <div className="flex flex-col">
          <span className="text-[10px] font-mono text-gray-400 font-semibold uppercase">ID: ASSET-{asset.id}</span>
          <span className="text-xs font-bold text-[#2C2C2C]">
            Stock: {asset.available_quantity}/{asset.total_quantity}
          </span>
        </div>

        {isAvailable ? (
          <button
            onClick={() => onBorrow(asset)}
            disabled={isBorrowing}
            className="text-xs font-bold text-[#5B7FAA] py-2 px-4 rounded-full border border-[#5B7FAA] hover:bg-[#5B7FAA] hover:text-white transition-all cursor-pointer shadow-xs disabled:opacity-50"
          >
            {isBorrowing ? 'Borrowing...' : 'Borrow Now'}
          </button>
        ) : (
          <button
            disabled
            className="text-xs font-bold text-gray-400 py-2 px-4 rounded-full border border-gray-200 cursor-not-allowed bg-gray-50 shrink-0"
          >
            Unavailable
          </button>
        )}
      </div>
    </div>
  );
};
