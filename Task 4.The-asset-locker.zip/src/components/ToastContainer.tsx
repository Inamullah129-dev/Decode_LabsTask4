import React, { useEffect } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  useEffect(() => {
    if (toasts.length > 0) {
      const timer = setTimeout(() => {
        onDismiss(toasts[0].id);
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [toasts, onDismiss]);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-20 right-6 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto p-4 rounded-2xl shadow-lg border flex items-start gap-3 backdrop-blur-md animate-in slide-in-from-top-4 duration-300 ${
            t.type === 'success'
              ? 'bg-[#5A7D6B] text-white border-[#5A7D6B]/80'
              : t.type === 'error'
              ? 'bg-[#B5655B] text-white border-[#B5655B]/80'
              : 'bg-[#5B7FAA] text-white border-[#5B7FAA]/80'
          }`}
        >
          <div className="mt-0.5 shrink-0">
            {t.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#D4A373]" />}
            {t.type === 'error' && <AlertTriangle className="w-5 h-5 text-white" />}
            {t.type === 'info' && <Info className="w-5 h-5 text-white" />}
          </div>
          <div className="flex-1 text-xs font-medium leading-relaxed">{t.message}</div>
          <button
            onClick={() => onDismiss(t.id)}
            className="text-white/70 hover:text-white p-1 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
