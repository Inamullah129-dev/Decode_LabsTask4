import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { db } from './src/server/db.ts';
import { generateToken, verifyToken, authenticateToken, requireAdmin } from './src/server/auth.ts';
import { askAiConcierge, generateInventoryInsights } from './src/server/ai.ts';

const app = express();
const PORT = 3000;

app.use(express.json());

// Logging middleware
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.url}`);
  }
  next();
});

// ==========================================
// AUTHENTICATION ENDPOINTS
// ==========================================

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Validation Error', message: 'Email and password are required' });
    }

    const user = db.getUserByEmail(email);
    if (!user || user.password_hash !== password) {
      return res.status(401).json({ error: 'Unauthorized', message: 'Invalid email or password credentials' });
    }

    const token = generateToken(user);
    res.status(200).json({
      token,
      user: { id: user.id, email: user.email, full_name: user.full_name, role: user.role }
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Server Error', message: err.message });
  }
});

app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, full_name } = req.body;
    if (!email || !password || !full_name) {
      return res.status(400).json({ error: 'Validation Error', message: 'All fields (email, password, full_name) are required' });
    }

    const newUser = db.createUser(email, password, full_name, 'borrower');
    const token = generateToken(newUser);
    res.status(201).json({
      token,
      user: { id: newUser.id, email: newUser.email, full_name: newUser.full_name, role: newUser.role }
    });
  } catch (err: any) {
    if (err.message.includes('already exists')) {
      return res.status(409).json({ error: 'Conflict', message: err.message });
    }
    res.status(400).json({ error: 'Bad Request', message: err.message });
  }
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
  res.status(200).json({ user: req.user });
});

// ==========================================
// ASSETS CRUD ENDPOINTS (PRD 7.1)
// ==========================================

app.get('/api/assets', (req, res) => {
  try {
    const { q, category, status } = req.query;
    const assets = db.getAssets(q as string, category as string, status as string);
    res.status(200).json(assets);
  } catch (err: any) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

app.get('/api/assets/categories', (req, res) => {
  res.status(200).json(db.getCategories());
});

app.get('/api/assets/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const asset = db.getAssetById(id);
  if (!asset) {
    return res.status(404).json({ error: 'Not Found', message: `Asset with ID ${id} was not found` });
  }
  res.status(200).json(asset);
});

app.post('/api/assets', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { name, description, category, location, total_quantity, available_quantity, image_url } = req.body;
    if (!name || total_quantity === undefined || available_quantity === undefined) {
      return res.status(400).json({ error: 'Bad Request', message: 'Name, total_quantity, and available_quantity are required' });
    }

    const created = db.createAsset({
      name,
      description: description || '',
      category: category || 'General',
      location: location || 'Storage Hub',
      total_quantity: Number(total_quantity),
      available_quantity: Number(available_quantity),
      image_url: image_url || 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=800&q=80'
    });

    res.status(201).json(created);
  } catch (err: any) {
    res.status(400).json({ error: 'Constraint Failure', message: err.message });
  }
});

app.put('/api/assets/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const updated = db.updateAsset(id, req.body);
    res.status(200).json(updated);
  } catch (err: any) {
    if (err.message === 'Asset not found') {
      return res.status(404).json({ error: 'Not Found', message: err.message });
    }
    res.status(400).json({ error: 'Bad Request', message: err.message });
  }
});

app.delete('/api/assets/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const success = db.deleteAsset(id);
    if (!success) {
      return res.status(404).json({ error: 'Not Found', message: 'Asset record does not exist' });
    }
    res.status(204).send();
  } catch (err: any) {
    if (err.message.includes('CONSTRAINT_RESTRICT')) {
      return res.status(409).json({ error: 'Conflict', message: err.message });
    }
    res.status(500).json({ error: 'Server Error', message: err.message });
  }
});

// ==========================================
// LOANS ENDPOINTS (PRD 7.2 & 7.3)
// ==========================================

app.get('/api/loans', authenticateToken, (req, res) => {
  try {
    const borrowerId = req.user?.role === 'admin' && req.query.all === 'true'
      ? undefined
      : req.user?.role === 'admin' && req.query.borrower_id
      ? parseInt(req.query.borrower_id as string, 10)
      : req.user?.role === 'borrower'
      ? req.user.id
      : undefined;

    const status = req.query.status as string;
    const loans = db.getLoans(borrowerId, status);
    res.status(200).json(loans);
  } catch (err: any) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

app.post('/api/loans', authenticateToken, (req, res) => {
  try {
    const { asset_id, due_date } = req.body;
    if (!asset_id) {
      return res.status(400).json({ error: 'Bad Request', message: 'asset_id is required' });
    }

    const loan = db.borrowAsset(Number(asset_id), req.user!.id, due_date);
    res.status(201).json(loan);
  } catch (err: any) {
    if (err.message.includes('OUT_OF_STOCK')) {
      return res.status(409).json({ error: 'Conflict - Out of Stock', message: err.message });
    }
    if (err.message.includes('CONFLICT') || err.message.includes('active borrowing')) {
      return res.status(409).json({ error: 'Conflict - Idempotency Lock', message: err.message });
    }
    res.status(400).json({ error: 'Bad Request', message: err.message });
  }
});

// Idempotent Return Endpoint (PRD 7.3 & 7.4)
app.put('/api/loans/:id/return', authenticateToken, (req, res) => {
  try {
    const loanId = parseInt(req.params.id, 10);
    const isAdmin = req.user?.role === 'admin';
    const result = db.returnAsset(loanId, req.user!.id, isAdmin);

    res.status(200).json({
      ...result.loan,
      _idempotent_note: result.alreadyReturned ? 'Transaction previously returned. Returned existing state 200 OK.' : 'Successfully returned item and incremented inventory.'
    });
  } catch (err: any) {
    if (err.message.includes('not found')) {
      return res.status(404).json({ error: 'Not Found', message: err.message });
    }
    if (err.message.includes('FORBIDDEN')) {
      return res.status(403).json({ error: 'Forbidden', message: err.message });
    }
    res.status(400).json({ error: 'Bad Request', message: err.message });
  }
});

// ==========================================
// STATS & AI CONCIERGE ENDPOINTS
// ==========================================

app.get('/api/stats', authenticateToken, (req, res) => {
  res.status(200).json(db.getStats());
});

app.post('/api/ai/concierge', authenticateToken, async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'Prompt required' });
    const reply = await askAiConcierge(prompt);
    res.status(200).json({ reply });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/ai/insights', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const report = await generateInventoryInsights();
    res.status(200).json({ report });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// VITE MIDDLEWARE & STATIC FALLBACK
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Asset Locker IPO Server booted on http://0.0.0.0:${PORT}`);
  });
}

startServer();
